# Git Labor Projekt

**Autor:** Mare Sepaste  
**Kuupäev:** 2026-02-21

## Eesmärk

Õppida Git workflow'sid, branch'e ja koostööd GitHub'iga.

## Tehnoloogiad

- Git
- GitHub
- Bash
